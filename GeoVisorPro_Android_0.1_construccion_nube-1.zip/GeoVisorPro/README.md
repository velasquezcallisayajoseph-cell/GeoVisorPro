# GeoVisor Pro — prototipo Android 0.1

Visor cartográfico Android de solo lectura, construido con Kotlin y osmdroid.

## Incluye
- Mapa base OpenStreetMap en línea.
- Gestos de zoom y desplazamiento.
- Selector de archivos Android.
- Visualización básica de geometrías GeoJSON (Point, LineString, Polygon y variantes multi).
- Visualización básica de trazos KML.
- Gestión simple de elementos importados.
- No modifica los archivos originales.

## Abrir el proyecto
1. Instala Android Studio (versión compatible con Android Gradle Plugin 8.7.3).
2. Abre la carpeta `GeoVisorPro`.
3. Espera la sincronización de Gradle.
4. Ejecuta en un dispositivo Android o emulador con Android 8.0 o superior.

## Estado real de formatos
La interfaz permite seleccionar archivos de distintos tipos, pero esta primera versión solo dibuja GeoJSON y trazos KML. No interpreta todavía la georreferenciación de GeoTIFF/JPG/PNG, ni las capas internas de GeoPDF, Shapefile, GeoPackage, MBTiles o KMZ. Esos formatos requieren integrar motores geoespaciales y se incorporarán por módulos; no se deben presentar como compatibles hasta validar su lectura y sistema de coordenadas.

## Siguiente fase recomendada
Integrar GDAL/PROJ para lectura raster/vectorial y reproyección; soporte de GeoPackage/MBTiles offline; parser KMZ; renderizado de GeoTIFF y GeoPDF; selector de mapas base y control de CRS. Añadir pruebas con archivos reales antes de publicar.
