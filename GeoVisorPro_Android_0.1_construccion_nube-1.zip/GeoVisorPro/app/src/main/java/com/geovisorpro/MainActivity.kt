package com.geovisorpro

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding
import org.json.JSONObject
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Polygon
import org.osmdroid.views.overlay.Polyline
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : AppCompatActivity() {
    private lateinit var map: MapView
    private lateinit var status: TextView
    private val pickFile = 501
    private val navy = Color.rgb(11,32,51)
    private val teal = Color.rgb(32,183,165)
    private val overlays = mutableListOf<org.osmdroid.views.overlay.Overlay>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().load(this, getSharedPreferences("osmdroid", MODE_PRIVATE))
        Configuration.getInstance().userAgentValue = packageName

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(244,247,250)) }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(18); setBackgroundColor(navy)
        }
        header.addView(TextView(this).apply {
            text = "GEOVISOR PRO"; setTextColor(Color.WHITE); textSize = 20f
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        header.addView(TextView(this).apply {
            text = "VISOR CARTOGRÁFICO  •  SOLO LECTURA"; setTextColor(Color.LTGRAY); textSize = 10f
        })
        root.addView(header)

        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; setPadding(8); setBackgroundColor(Color.WHITE)
        }
        toolbar.addView(actionButton("＋ Abrir", teal) { openFile() }, weight())
        toolbar.addView(actionButton("⌖ Mi vista", navy) {
            map.controller.setZoom(5.0)
            map.controller.setCenter(GeoPoint(-16.5, -68.15))
            status.text = "Vista centrada en La Paz (referencia inicial)"
        }, weight())
        toolbar.addView(actionButton("Capas", navy) { showLayers() }, weight())
        root.addView(toolbar)

        map = MapView(this).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            controller.setZoom(5.0)
            controller.setCenter(GeoPoint(-16.5, -68.15))
            isTilesScaledToDpi = true
        }
        root.addView(map, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(12); setBackgroundColor(Color.WHITE)
        }
        status = TextView(this).apply {
            text = "Listo · Mapa base en línea · Acerca o aleja con dos dedos"
            setTextColor(navy); textSize = 12f
        }
        bottom.addView(status)
        bottom.addView(TextView(this).apply {
            text = "GeoVisor Pro 0.1  |  Archivos originales protegidos"
            setTextColor(Color.GRAY); textSize = 10f; gravity = Gravity.END
        })
        root.addView(bottom)
        setContentView(root)
    }

    private fun weight() = LinearLayout.LayoutParams(0, 48, 1f).apply { setMargins(3,0,3,0) }
    private fun actionButton(label: String, color: Int, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 11f; isAllCaps = false
        setTextColor(Color.WHITE); backgroundTintList = android.content.res.ColorStateList.valueOf(color)
        setOnClickListener { action() }
    }

    private fun openFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "application/geo+json", "application/json", "application/vnd.google-earth.kml+xml",
                "application/vnd.google-earth.kmz", "application/pdf", "image/tiff", "image/jpeg",
                "image/png", "application/geopackage+sqlite3", "application/x-shapefile",
                "application/octet-stream"
            ))
        }
        startActivityForResult(i, pickFile)
    }

    @Deprecated("Legacy callback retained for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickFile || resultCode != Activity.RESULT_OK) return
        val uri = data?.data ?: return
        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        val name = queryName(uri)
        val ext = name.substringAfterLast('.', "").lowercase()
        try {
            when (ext) {
                "geojson", "json" -> loadGeoJson(uri)
                "kml" -> loadKml(uri)
                "kmz" -> status.text = "KMZ seleccionado: $name · La extracción KMZ se incorporará en la siguiente versión."
                "pdf", "tif", "tiff", "gpkg", "shp", "mbtiles", "jpg", "jpeg", "png" ->
                    status.text = "$name seleccionado · Este formato requiere el módulo geoespacial avanzado; no se dibuja como si estuviera georreferenciado."
                else -> status.text = "Formato no reconocido: $name"
            }
        } catch (e: Exception) {
            status.text = "No se pudo leer el archivo: ${e.localizedMessage ?: "error"}"
        }
    }

    private fun queryName(uri: Uri): String {
        var result = "archivo"
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) result = c.getString(idx) ?: result
            }
        }
        return result
    }

    private fun loadGeoJson(uri: Uri) {
        val text = contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
        val root = JSONObject(text)
        val features = if (root.optString("type") == "FeatureCollection") root.optJSONArray("features") else null
        var count = 0
        if (features != null) {
            for (i in 0 until features.length()) {
                val geom = features.optJSONObject(i)?.optJSONObject("geometry") ?: continue
                count += drawGeometry(geom)
            }
        } else if (root.optString("type") == "Feature") {
            count += drawGeometry(root.optJSONObject("geometry") ?: return)
        } else count += drawGeometry(root)
        map.invalidate()
        status.text = "GeoJSON cargado · $count geometría(s) · Solo visualización"
    }

    private fun drawGeometry(g: JSONObject): Int {
        val type = g.optString("type")
        val coords = g.optJSONArray("coordinates") ?: return 0
        when (type) {
            "Point" -> {
                val p = coordsToPoint(coords) ?: return 0
                val marker = org.osmdroid.views.overlay.Marker(map).apply {
                    position = p; title = "Elemento GeoJSON"; setAnchor(org.osmdroid.views.overlay.Marker.ANCHOR_CENTER, org.osmdroid.views.overlay.Marker.ANCHOR_BOTTOM)
                }
                map.overlays.add(marker); overlays.add(marker)
            }
            "LineString" -> addLine(coords)
            "MultiLineString" -> for (i in 0 until coords.length()) addLine(coords.getJSONArray(i))
            "Polygon" -> addPolygon(coords)
            "MultiPolygon" -> for (i in 0 until coords.length()) addPolygon(coords.getJSONArray(i))
            else -> return 0
        }
        return 1
    }

    private fun coordsToPoint(a: org.json.JSONArray): GeoPoint? {
        if (a.length() < 2) return null
        return GeoPoint(a.getDouble(1), a.getDouble(0))
    }

    private fun addLine(a: org.json.JSONArray) {
        val line = Polyline().apply {
            outlinePaint.color = teal; outlinePaint.strokeWidth = 5f
            for (i in 0 until a.length()) coordsToPoint(a.getJSONArray(i))?.let { addPoint(it) }
        }
        map.overlays.add(line); overlays.add(line)
    }

    private fun addPolygon(rings: org.json.JSONArray) {
        if (rings.length() == 0) return
        val polygon = Polygon().apply {
            fillPaint.color = Color.argb(45, 32,183,165)
            outlinePaint.color = teal; outlinePaint.strokeWidth = 4f
            val ring = rings.getJSONArray(0)
            for (i in 0 until ring.length()) coordsToPoint(ring.getJSONArray(i))?.let { points.add(it) }
        }
        map.overlays.add(polygon); overlays.add(polygon)
    }

    private fun loadKml(uri: Uri) {
        val xml = contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
        val regex = Regex("<coordinates>(.*?)</coordinates>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))
        var count = 0
        regex.findAll(xml).forEach { match ->
            val pts = match.groupValues[1].trim().split(Regex("\\s+")).mapNotNull { token ->
                val v = token.split(",")
                if (v.size >= 2) runCatching { GeoPoint(v[1].toDouble(), v[0].toDouble()) }.getOrNull() else null
            }
            if (pts.size >= 2) {
                val line = Polyline().apply { outlinePaint.color = teal; outlinePaint.strokeWidth = 5f; setPoints(pts) }
                map.overlays.add(line); overlays.add(line); count++
            }
        }
        map.invalidate()
        status.text = "KML cargado · $count trazo(s) detectado(s) · Solo visualización"
    }

    private fun showLayers() {
        val options = arrayOf("Mapa base OpenStreetMap", "Elementos importados (${overlays.size})", "Limpiar elementos importados")
        AlertDialog.Builder(this).setTitle("Capas").setItems(options) { _, which ->
            when (which) {
                0 -> status.text = "Mapa base OpenStreetMap"
                1 -> status.text = "${overlays.size} elemento(s) cargado(s)"
                2 -> {
                    overlays.forEach { map.overlays.remove(it) }; overlays.clear()
                    map.invalidate(); status.text = "Capas importadas retiradas de la vista"
                }
            }
        }.show()
    }

    override fun onResume() { super.onResume(); if (::map.isInitialized) map.onResume() }
    override fun onPause() { if (::map.isInitialized) map.onPause(); super.onPause() }
}
